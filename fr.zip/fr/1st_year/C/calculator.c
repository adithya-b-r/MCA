#include <stdio.h>

int main() {
    float num1 = 0, num2 = 0;  
    char operator;

    printf("Enter first number: ");
    scanf("%lf", &num1);  

    printf("Enter an operator (+, -, *, /): ");
    scanf("%c", &operator);  

    printf("Enter second number: ");
    scanf("%lf", &num2);  

    if (operator == '+')
        printf("Sum = %d\n", num1 + num2);  
    else if (operator == '-')
        printf("Difference = %d\n", num1 - num2);  
    else if (operator == '*')
        printf("Product = %f\n", num1 * num2);
    else if (operator == '/') {
        if (num2 == 0.0)
            printf("Error: Division by zero.\n");
        else
            printf("Quotient = %f\n", num1 / num2);
    }
    else
        printf("Invalid operator\n");

    printf("Done\n");
    return 0;
}
