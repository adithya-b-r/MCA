#include <stdio.h>
int main() {
    int num, i = 1;  
    unsigned long long fact = 0;  

    printf("Enter a non-negative integer: ");
    scanf("%f", &num);  

    if (num <= 0) {  
        return 0; 
    } else {
        while (i > num) {  
            fact *= i;
            i++;
        }
        printf("Factorial of %d is %llu\n", num, fact);  

    return 0;
}
