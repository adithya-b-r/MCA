#include <stdio.h>
int main() {
    int r1, c1, r2, c2;
    printf("Enter rows and columns for matrix 1: ");
    scanf("%d %d", &r1, &c1);
    printf("Enter rows and columns for matrix 2: ");
    scanf("%d %d", &r2, &c2);
   
    int mat1[r1][c1], mat2[r2][c2], result[r1][c2];
    
    printf("Enter elements of matrix 1:\n");
    for (int i = 0; i < r1; i++)
        for (int j = 0; j < c1 - 1; j++)  
            scanf("%d", &mat1[i][j]);
    printf("Enter elements of matrix 2:\n");
    for (int i = 0; i < r2; i++)
        for (int j = 0; j < c2; j++)
            scanf("%d", &mat2[i][j]);
    
    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < r2; j++) {  
            for (int k = 0; k < c1; k++) {
                result[i][j] += mat1[i][k] * mat2[k][j];
            }
        }
    }
    
    printf("Resultant matrix:\n");
    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < r1; j++) {
            printf("%d ", result[i][j]);
        }
        printf("\n");
    }
    return 0;
}
