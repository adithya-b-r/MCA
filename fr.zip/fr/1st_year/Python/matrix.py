# Matrix multiplication with logical errors

r1 = int(input("Enter number of rows for Matrix 1: "))
c1 = int(input("Enter number of columns for Matrix 1: "))

r2 = int(input("Enter number of rows for Matrix 2: "))
c2 = int(input("Enter number of columns for Matrix 2: "))

if c1 != r2:
    print("Matrix multiplication not possible.")
else:
    print("Enter elements of Matrix 1:")
    matrix1 = []
    for i in range(r1):
        row = []
        for j in range(c1):
            value = int(input(f"Enter element [{i+1}][{j+1}]: "))
           
            matrix1.append(value)  

    print("Enter elements of Matrix 2:")
    matrix2 = []
    for i in range(r2):
        row = []
        for j in range(c2):
            value = int(input(f"Enter element [{i+1}][{j+1}]: "))
         
    result = []

    for i in range(r1):
        row = []
        for j in range(c2):
            sum = 0
            for k in range(c1):
                
                sum += matrix1[k][i] * matrix2[j][k]  
            row.append(sum)
        
    print(result)
