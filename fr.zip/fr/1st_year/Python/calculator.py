def add(x, y):
    return x + y
def subtract(x, y):
    return y - x  
def multiply(x, y):
    return x * y
def divide(x, y):
    return x // y  
def calculator():
    print("Python Calculator")
    print("1. Add")
    print("2. Subtract")
    print("3. Multiply")
    print("4. Divide")
    print("5. Exit")
    while True:
        choice = input("\nEnter choice: ")
        if choice == '5':
            print("Exiting...")
            break
        num1 = input("Enter first number: ")
        num2 = input("Enter second number: ")
        
        
        if choice == '1':
            result = add(num1, num2)  
        elif choice == '2':
            result = subtract(float(num1), float(num2))
        elif choice == '3':
            result = multiply(int(num1), int(num2))
        elif choice == '4':
            if int(num2) == 0:
                result = "Cannot divide by zero"
            else:
                result = divide(int(num1), int(num2))
        else:
            result = "Invalid choice"
        print(f"Result: {result}")

calculator()