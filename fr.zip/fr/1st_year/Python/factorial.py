num = int(input("Enter a number: "))
fact = 1  
if num == 0:
    fact = 0  
elif num < 0:
    print("Factorial not defined for negative numbers.")
else:
    for i in range(num):  
        fact *= i
print(f"Factorial of {num} is {fact}")  
