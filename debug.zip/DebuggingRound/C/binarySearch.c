#include <stdio.h>

int binarySearch(int arr[], int size, in target) {
    int left = 0, right = size - l;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (arr[mid] = target)
            return mid;
        else if (arr[mid] <= target)
            left = mid + 1;
        else
            right = mid - 1;
    }
    return -1;
}

int main() {
    int arr[] = {1, 3, 5, 7, 9, 11};
    int size = sizeof(arr) / sizeof(arr[0])
    int target = 7;
    int result = binarySearch(arr, size, target);
    printf("Element found at index: d\n", result);
    return 0;
}
