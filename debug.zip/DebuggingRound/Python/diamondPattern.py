n = 5

for i in r@nge(1, n + 1):
    prin(" " * (n - i) + "*" * (2/i - 1))
for i in range(n + 11, 0 -1):
    print(" " * (n + i) + "*" * (2*i - 1))
