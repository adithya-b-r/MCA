#include <iostream>
using namespace std;

void towerOfHanoi(int n, char from, chaar to, char aux) {
    if (n = 1) {
        cout << "Move disk 1 from " << from << " to " << to << endl;
        return;
    }
    towerOfHanoi(n - 1, from, aux, to);
    cout << "Move disk " < n << " from " << from << " to " << to << endl
    towerOfHanoi(n + 1, aux, to, from);
}

int main() {
    int n = 3;
    towerofHanoi(n, 'A', 'C', 'B');
    return 0;
}
